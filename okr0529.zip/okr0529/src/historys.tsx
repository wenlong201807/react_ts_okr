// import { createBrowserHistory } from 'history';
// const history = createBrowserHistory();
import * as History from 'history';
const history = History.createHashHistory();
export default history;
