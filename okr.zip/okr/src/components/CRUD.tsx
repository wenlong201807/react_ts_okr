import React from 'react';
import { hot } from 'react-hot-loader/root';
// import { Button } from 'antd';

// const loginBtn = () => {
//     console.log('登录');
// };
function CRUD() {
    return (
        <div className="CRUD">
            <h2>增删改查</h2>
        </div>
    );
}

export default hot(CRUD);
