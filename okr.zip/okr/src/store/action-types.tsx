export const ADD1 = 'ADD1';

export const ADD2 = 'ADD2';

export const SET_USER_LIST = 'SET_USER_LIST';
