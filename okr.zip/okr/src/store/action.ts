// export const user = () => {
//     return dispatch => {
//         axios.get().then(res => {
//             console.log(res)
//             //
//             getArticleListSucccessActionres（res)
//         })
//     }
// }
// const getArticleListSucccessAction = payload => ({
//     type: actionTypes.GET_ARTICLE_LIST,
//     payload
// })
