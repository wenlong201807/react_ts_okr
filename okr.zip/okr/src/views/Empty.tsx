import React from 'react';
import { hot } from 'react-hot-loader/root';
// import { Button } from 'antd';

// const loginBtn = () => {
//     console.log('登录');
// };
function Empty() {
    return (
        <div className="Empty">
            <h2>我是错误页面</h2>
        </div>
    );
}

export default hot(Empty);
